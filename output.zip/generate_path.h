#ifndef GENERATE_PATH_H
#define GENERATE_PATH_H

#include <iostream>
#include <opencv2/opencv.hpp>
#include <gdal.h>
#include <ogr_geometry.h>
#include <ogr_feature.h>
#include <ogrsf_frmts.h>
#include <vector>

// Struct declarations
struct Point3D {
    double x, y, z;
};

struct Polygon3D {
    Point3D points[4];
};

// Function prototypes
double distance(const Point3D& a, const Point3D& b);
std::vector<Point3D> greedyTSP(const Point3D& start, const std::vector<Point3D>& points);
std::vector<Point3D> interpolatePoints(const std::vector<Point3D>& originalResult, double assumedZ, double interval);

#endif // GENERATE_PATH_H
