./MyExecutableName ../example.txt
